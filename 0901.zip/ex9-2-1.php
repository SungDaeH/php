<?php
    $servername='localhost';
    $username='root';
    $password='';
    $dbname='sample';
    
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    $sql = "create database sample2;";
    $result=mysqli_query($conn, $sql);

    if($result)
        echo "데이터베이스 성공!";
    else
        echo "데이터베이스 실패 : ".mysqli_erorr($conn);

    mysqli_close($conn);
?>