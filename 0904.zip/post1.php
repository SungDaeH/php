<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>폼 양식 예</h3>
    <form action = "post1_process.php" method = "post">
    이름 : <input type = "text" name = "name"><br>
    전화번호 : <input type="text" name = "tel"><br>
    주소 : <input type="text" name = "address"><br>
    <input type="submit" value = "저장">
    </form>
</body>
</html>