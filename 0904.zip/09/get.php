<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>GET 방식</h3>
    <a href="get_process.php?id=kim111&level=7">회원정보</a>
</body>
</html>