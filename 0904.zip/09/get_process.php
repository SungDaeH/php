<?php
    $id=$_GET["id"];
    $level=$_GET["level"];

    echo "<h3>회원 정보</h3>";
    echo "- 아이디 : $id<br>";
    echo "- 레벨 : $level";
?>