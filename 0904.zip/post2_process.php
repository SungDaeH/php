<?php
    $name = $_POST["name"];
    $tel = $_POST["tel"];
    $address = $_POST["address"];

    $sercername="root";
    $username="user";
    $password="12345";
    $abname="sample";

    $conn = mysqli_connect($sercername,$username,$password,$abname);

    $sql = "insert into friend(name, tel, address) values('$name','$tel','$address');";
    $result = mysqli_query($conn, $sql);

    if($result)
        echo "friend 테이블에 데이터 삽입 완료!";
    else
        echo "friend 테이블에 데이터 삽입 오류".mysqli_error($conn);

    myspli_close($conn);
?>

